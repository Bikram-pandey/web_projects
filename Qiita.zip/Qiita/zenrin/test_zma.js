const start = { lat: 35.681406, lng: 139.767132 }; // 東京駅
const destination = { lat: 35.6895, lng: 139.6917 }; // 東京都庁舎
const waypoints = [
    { lat: 35.658034, lng: 139.701636 }, // 渋谷
    { lat: 35.6890, lng: 139.7004 }, // 新宿 (追加ウェイポイント)
    { lat: 35.6896, lng: 139.6920 }  // 六本木 (追加ウェイポイント)
];

// ZMALoaderで地図をロード
ZMALoader.setOnLoad(function (mapOptions, error) {
    if (error) return console.error(error);

    mapOptions.center = new ZDC.LatLng(start.lat, start.lng); // 中心点の緯度経度（東京駅）
    mapOptions.mouseWheelReverseZoom = true;  // マウスホイールのズーム方向の反転を指定
    mapOptions.zoom = 13;

    map = new ZDC.Map(document.getElementById('ZMap'), mapOptions, function () {
        // コントロールを追加
        map.addControl(new ZDC.ZoomButton('top-left'));
        map.addControl(new ZDC.ScaleBar('bottom-left'));

        // マーカーを追加
        map.addWidget(new ZDC.Marker(new ZDC.LatLng(start.lat, start.lng), { styleId: ZDC.MARKER_COLOR_ID_BLUE_S }));
        map.addWidget(new ZDC.Marker(new ZDC.LatLng(destination.lat, destination.lng), { styleId: ZDC.MARKER_COLOR_ID_RED_S }));
        waypoints.forEach((waypoint, index) => {
            map.addWidget(new ZDC.Marker(new ZDC.LatLng(waypoint.lat, waypoint.lng), { styleId: ZDC.MARKER_COLOR_ID_GREEN_S }));
        });

        // すべてのウェイポイントをカンマ区切りで結合
        const waypointString = waypoints.map(point => `${point.lng},${point.lat}`).join(',');

        // Fetch optimal route with multiple waypoints
        fetch(`https://test-web.zmaps-api.com/route/route_mbn/drive_tsp?search_type=1&from=${start.lng},${start.lat}&to=${destination.lng},${destination.lat}&waypoint=${waypointString}`, {
            method: 'GET',
            headers: {
                'x-api-key': 'O8iPysCxWSagAdi6h70ub7I3DreHA5Qi7EEyUorM',
                'Authorization': 'ip'
            }
        })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'OK' && data.result?.item?.length > 0) {
                    console.log(data);
                    const decodedPath = data.result.item[0].route?.link?.flatMap(link => link.line.coordinates.map(coord => new ZDC.LatLng(coord[1], coord[0])));
                    if (decodedPath?.length) {
                        map.addWidget(new ZDC.Polyline(decodedPath, { color: "blue", width: 4, opacity: 1 }));
                    } else {
                        console.error("No decoded route data.");
                    }
                } else {
                    console.error("Failed to fetch route.", data);
                }
            })
            .catch(console.error);
    }, function () {
        console.error('Failed to generate the map.');
    });
});
